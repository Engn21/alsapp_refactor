import { prisma } from "../lib/prisma";
import { Response } from "express";
import { z } from "zod";
import { AuthedRequest } from "../middleware/auth";

const CreateCropDto = z.object({
  cropType: z.string().min(1),
  plantingDate: z.string().datetime(),
  harvestDate: z.string().datetime().optional(),
  notes: z.string().optional(),
});

export async function listCrops(req: AuthedRequest, res: Response) {
  const crops = await prisma.crop.findMany({
    where: { userId: req.user!.id },
    orderBy: { plantingDate: "desc" },
  });
  res.json(crops);
}

export async function createCrop(req: AuthedRequest, res: Response) {
  const dto = CreateCropDto.parse(req.body);
  const crop = await prisma.crop.create({
    data: {
      userId: req.user!.id,
      cropType: dto.cropType,
      plantingDate: new Date(dto.plantingDate),
      harvestDate: dto.harvestDate ? new Date(dto.harvestDate) : null,
      notes: dto.notes,
    },
  });
  res.status(201).json(crop);
}