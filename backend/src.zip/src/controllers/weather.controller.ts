import { Request, Response } from "express";
import axios from "axios";

function getCoords(req: Request) {
  const lat = Number(req.body?.lat ?? req.query.lat);
  const lon = Number(req.body?.lon ?? req.query.lon);
  return { lat, lon };
}

export async function weather(req: Request, res: Response) {
  try {
    const { lat, lon } = getCoords(req);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      return res.status(400).json({ error: "Missing or invalid lat/lon" });
    }
    const apiKey = process.env.OPENWEATHER_API_KEY;
    if (!apiKey) return res.status(500).json({ error: "OPENWEATHER_API_KEY missing" });

    const r = await axios.get("https://api.openweathermap.org/data/2.5/weather", {
      params: { lat, lon, appid: apiKey },
      timeout: 8000,
    });

    return res.json(r.data);
  } catch (e: any) {
    const status = e?.response?.status ?? 500;
    return res.status(status).json({ error: e?.message ?? "weather error" });
  }
}

export async function weatherSummary(req: Request, res: Response) {
  try {
    const { lat, lon } = getCoords(req);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      return res.status(400).json({ error: "Missing or invalid lat/lon" });
    }
    const apiKey = process.env.OPENWEATHER_API_KEY;
    if (!apiKey) return res.status(500).json({ error: "OPENWEATHER_API_KEY missing" });

    const r = await axios.get("https://api.openweathermap.org/data/2.5/weather", {
      params: { lat, lon, appid: apiKey },
      timeout: 8000,
    });

    const data = r.data;
    const main = data?.weather?.[0]?.main ?? "";
    const c = data?.main?.temp != null ? data.main.temp - 273.15 : null;
    return res.json({ summary: c != null ? `${main} / ${c.toFixed(1)}°C` : main });
  } catch (e: any) {
    const status = e?.response?.status ?? 500;
    return res.status(status).json({ error: e?.message ?? "weather summary error" });
  }
}
