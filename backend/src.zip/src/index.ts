import { createServer } from "./server";
import dotenv from "dotenv";
dotenv.config();

const app = createServer();
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`API running on :${port}`));
