import { Router } from "express";
import { requireAuth } from "../middleware/auth";
import { createCrop, listCrops } from "../controllers/crops.controller";
const r = Router();
r.use(requireAuth);
r.get("/", listCrops);
r.post("/", createCrop);
export default r;