// server.ts / createServer()
import express from "express";
import cors from "cors";
import helmet from "helmet";

export function createServer() {
  const app = express();

  // 1) CORS'u ERKEN ve tek seferde uygula
  app.use(cors({
    // Sadece dev origin’lerini açıkça izin ver (hem localhost hem 127.0.0.1, port fark etmeksizin)
    origin: [/^http:\/\/localhost:\d+$/, /^http:\/\/127\.0\.0\.1:\d+$/],
    methods: ["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
    allowedHeaders: ["Content-Type","Authorization","X-Requested-With"],
    credentials: false,                 // cookie kullanmıyorsan false kalsın
    optionsSuccessStatus: 204,          // bazı tarayıcılar 204 bekliyor
    preflightContinue: false            // CORS preflight burada bitirilsin
  }));

  // Ayrı bir app.options(*) çağrısına artık gerek yok:
  // app.options("*", cors())  <-- kaldır

  app.use(express.json());

  // 2) Basit log (OPTIONS dahil görebilmek iyi olur)
  app.use((req, _res, next) => { console.log(req.method, req.path); next(); });

  // 3) Helmet: COEP/CORP ayarları XHR’ı engellemez; mevcut ayar tamam.
  app.use(helmet({
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  }));

  // 4) ROUTES
  app.use("/api/auth", /* ... */);
  app.use("/api/crops", /* ... */);
  app.use("/api/weather", /* ... */);

  app.get("/health", (_req, res) => res.json({ ok: true }));

  // 5) Hata yakalayıcı en sonda
  app.use(/* errorHandler */);

  return app;
}
